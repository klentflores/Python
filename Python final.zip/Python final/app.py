from flask import Flask, render_template, request, redirect, url_for, session
from db.dbhelper import getall, addrecord, getrecord, deleterecord, updaterecord
from datetime import datetime
from flask import flash
import sqlite3
import base64
import re
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"


@app.route("/")
def index():
    return render_template("index.html", show_login=True)


@app.route('/check', methods=['GET'])
def check_student():
    idno = request.args.get('idno')
    student = getrecord("students", idno=idno)
    if student:
        student = student[0]
        name = student['firstname'] + ' ' + student['lastname']
        course_level = student['course'] + ' ' + student['level']
        import datetime
        now = datetime.datetime.now()
        time_in = now.strftime("%H:%M:%S")
        date = now.strftime("%Y-%m-%d")
        conn = sqlite3.connect('db/klent.db')
        c = conn.cursor()
        c.execute("INSERT INTO attendance (idno, name, course_level, time_in, date) VALUES (?, ?, ?, ?, ?)", (idno, name, course_level, time_in, date))
        conn.commit()
        conn.close()
        html = '''
        <center>
            <img src="''' + url_for('static', filename='images/' + (student['avatar'] if student['avatar'] else 'default_avatar.png')) + '''" 
                 style="width:100px;height:100px;border-radius:50%;object-fit:cover;margin-bottom:10px;">
        </center>
        <table class="w3-table-all">
            <tr><td>IDNO</td><td>''' + student['idno'] + '''</td></tr>
            <tr><td>LASTNAME</td><td>''' + student['lastname'] + '''</td></tr>
            <tr><td>FIRSTNAME</td><td>''' + student['firstname'] + '''</td></tr>
            <tr><td>COURSE</td><td>''' + student['course'] + '''</td></tr>
            <tr><td>LEVEL</td><td>''' + student['level'] + '''</td></tr>
        </table>
        '''
        return html
    else:
        return 'STUDENT NOT FOUND'


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"].strip()
        user = getrecord("user", email=email)
        if user:
            if user[0]["password"] == password:
                session['user'] = email
                return redirect(url_for('admin'))
            else:
                flash('Invalid email or password')
                return render_template("login.html", title="Login")
        else:
            flash('Email not registered. Please register first.')
            return render_template("login.html", title="Login")
    return render_template("login.html", title="Login")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"].strip()
        confirm_password = request.form["confirm_password"].strip()

        if password != confirm_password:
            flash('Passwords do not match. Please try again.')
            return render_template("register.html", title="Register")
        if getrecord("user", email=email):
            flash('Email is already taken. Please use a different email.')
            return render_template("register.html", title="Register")

        addrecord("user", email=email, password=password)
        flash('Registration successful! You can now log in.')
        return redirect(url_for('login'))
    return render_template("register.html", title="Register")


@app.route("/logout")
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))


@app.route("/admin", methods=["GET", "POST"])
def admin():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"].strip()
        edit_id = request.form.get("edit_id")
        if edit_id:
            updaterecord("user", {"email": email, "password": password}, id=edit_id)
        else:
            addrecord("user", email=email, password=password)
        return redirect(url_for('admin'))

    users = getall("user")
    edit_id = request.args.get("edit_id")
    edit_user = getrecord("user", id=edit_id)[0] if edit_id else None
    return render_template("admin.html", users=users, edit_user=edit_user, edit_id=edit_id, title="User Management")


@app.route('/admin/delete_user/<int:user_id>')
def delete_user(user_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    deleterecord("user", id=user_id)
    return redirect(url_for("admin"))


@app.route("/studentmngt", methods=["GET", "POST"])
def student_mngt():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == "POST":
        idno = request.form["idno"].strip()
        lastname = request.form["lastname"].strip()
        firstname = request.form["firstname"].strip()
        course = request.form["course"].strip()
        level = request.form["level"].strip()
        edit_id = request.form.get("edit_id")
        avatar_data = request.form.get("avatar")
        avatar_file = request.files.get("avatar")
        avatar_filename = None

        if avatar_data and avatar_data.startswith("data:image/"):
            header, encoded = avatar_data.split(",", 1)
            avatar_bytes = base64.b64decode(encoded)
            avatar_filename = f"{idno}.png"
            with open(os.path.join("static/images", avatar_filename), "wb") as f:
                f.write(avatar_bytes)
        elif avatar_file and avatar_file.filename != "":
            avatar_filename = avatar_file.filename
            avatar_file.save(os.path.join("static/images", avatar_filename))

        data = {
            "idno": idno,
            "lastname": lastname,
            "firstname": firstname,
            "course": course,
            "level": level
        }
        if avatar_filename:
            data["avatar"] = avatar_filename

        if edit_id:
            updaterecord("students", data, id=edit_id)
        else:
            addrecord("students", **data)

        return redirect(url_for("student_mngt"))

    students_list = getall("students")
    edit_id = request.args.get("edit_id")
    edit_student = getrecord("students", id=edit_id)[0] if edit_id else None
    return render_template("studentmngt.html", students=students_list, edit_student=edit_student)


@app.route("/student/add", methods=["GET", "POST"])
def add_student_page():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == "POST":
        idno = request.form["idno"].strip()
        lastname = request.form["lastname"].strip()
        firstname = request.form["firstname"].strip()
        course = request.form["course"].strip()
        level = request.form["level"].strip()
        avatar_data = request.form.get("avatar")
        avatar_filename = None

        if avatar_data:
            header, encoded = avatar_data.split(",", 1)
            avatar_bytes = base64.b64decode(encoded)
            avatar_filename = f"{idno}.png"
            with open(os.path.join("static/images", avatar_filename), "wb") as f:
                f.write(avatar_bytes)

        addrecord(
            "students",
            idno=idno,
            lastname=lastname,
            firstname=firstname,
            course=course,
            level=level,
            avatar=avatar_filename
        )
        return redirect(url_for("student_mngt"))

    return render_template("student.html", student=None)


@app.route("/student/edit/<int:student_id>", methods=["GET", "POST"])
def edit_student_page(student_id):
    if 'user' not in session:
        return redirect(url_for('login'))

    student = getrecord("students", id=student_id)[0]

    if request.method == "POST":
        idno = request.form["idno"].strip()
        lastname = request.form["lastname"].strip()
        firstname = request.form["firstname"].strip()
        course = request.form["course"].strip()
        level = request.form["level"].strip()
        avatar_data = request.form.get("avatar")
        data = {
            "idno": idno,
            "lastname": lastname,
            "firstname": firstname,
            "course": course,
            "level": level
        }

        if avatar_data:
            header, encoded = avatar_data.split(",", 1)
            avatar_bytes = base64.b64decode(encoded)
            avatar_filename = f"{idno}.png"
            with open(os.path.join("static/images", avatar_filename), "wb") as f:
                f.write(avatar_bytes)
            data["avatar"] = avatar_filename

        updaterecord("students", data, id=student_id)
        return redirect(url_for("student_mngt"))

    return render_template("student.html", student=student)


@app.route('/student/delete/<int:student_id>')
def delete_student(student_id):
    if 'user' not in session:
        return redirect(url_for('login'))

    deleterecord("students", id=student_id)
    return redirect(url_for("student_mngt"))


@app.route("/attend", methods=['GET'])
def attend():
    selected_date = request.args.get('date')
    if not selected_date:
        now = datetime.now()
        selected_date = now.strftime("%Y-%m-%d")

    conn = sqlite3.connect('db/klent.db')
    c = conn.cursor()
    c.execute("SELECT idno, name, course_level, time_in FROM attendance WHERE date = ?", (selected_date,))
    records = c.fetchall()
    conn.close()

    formatted_records = []
    for record in records:
        time_in = datetime.strptime(record[3], "%H:%M:%S")
        time_in = time_in.strftime("%I:%M %p")
        formatted_records.append((record[0], record[1], record[2], time_in))

    return render_template('attend.html', records=formatted_records, selected_date=selected_date)


@app.route('/attendance', methods=['POST'])
def record_attendance():
    idno = request.form['idno']
    student = getrecord("students", idno=idno)
    if student:
        student = student[0]
        name = student['firstname'] + ' ' + student['lastname']
        course_level = student['course'] + ' ' + student['level']
        import datetime
        now = datetime.datetime.now()
        time_in = now.strftime("%H:%M:%S")
        date = now.strftime("%Y-%m-%d")
        conn = sqlite3.connect('db/klent.db')
        c = conn.cursor()
        c.execute("INSERT INTO attendance (idno, name, course_level, time_in, date) VALUES (?, ?, ?, ?, ?)", (idno, name, course_level, time_in, date))
        conn.commit()
        conn.close()
        return 'Attendance recorded successfully!'
    else:
        return 'Student not found', 404


if __name__ == "__main__":
    app.run(debug=True)
